import React, { useState } from 'react';
import './App.css';

function TodoItem({ todo, onToggleStatus }) {
  return (
    <div className="todo-item">
      <h3>{todo.title}</h3>
      <p>{todo.content}</p>
      <button onClick={() => onToggleStatus(todo.id)}>
        {todo.isDone ? 'Canceled' : 'Done'}
      </button>
      <button onClick={() => onDelete(todo.id)}>Delete</button>
    </div>
  );
}

function AddTodoForm({ onAddTodo }) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;
    onAddTodo({
      id: Date.now(),
      title,
      content,
      isDone: false
    });
    setTitle('');
    setContent('');
  };

  return (
    <form onSubmit={handleSubmit} className="yolo">
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <input
        type="text"
        placeholder="Content"
        value={content}
        onChange={(e) => setContent(e.target.value)}
      />
      <button type="submit">Add</button>
    </form>
  );
}

function App() {
  const [todos, setTodos] = useState([]);

  const addTodo = (newTodo) => {
    setTodos([...todos, newTodo]);
  };

  const toggleStatus = (id) => {
    setTodos(
      todos.map((todo) =>
        todo.id === id ? { ...todo, isDone: !todo.isDone } : todo
      )
    );
  };

  const workingTodos = todos.filter((todo) => !todo.isDone);
  const doneTodos = todos.filter((todo) => todo.isDone);

  return (
    <div className="app">
      <div className="container">
        <AddTodoForm onAddTodo={addTodo} />
        <div className="todo-list">
          <h1>Working</h1>
          {workingTodos.map((todo) => (
            <TodoItem key={todo.id} todo={todo} onToggleStatus={toggleStatus} />
          ))}
        </div>
        <div className="todo-list">
          <h1>Done</h1>
          {doneTodos.map((todo) => (
            <TodoItem key={todo.id} todo={todo} onToggleStatus={toggleStatus} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;
